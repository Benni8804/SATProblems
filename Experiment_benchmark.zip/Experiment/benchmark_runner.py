import time
import argparse
import csv
import os
from cnf_parser import parse_dimacs
from solvers import ResolutionSolver, DPSolver, DPLLSolver, CDCLSolver

# Map solver names to classes
SOLVER_MAP = {
    "resolution": ResolutionSolver,
    "dp": DPSolver,
    "dpll": DPLLSolver,
    "cdcl": CDCLSolver,
}

def run_solver(solver_name, file_path, timeout=None):
    print(f"Running {solver_name.upper()} on {file_path}...")
    clauses = parse_dimacs(file_path)
    SolverClass = SOLVER_MAP[solver_name.lower()]
    solver = SolverClass(clauses)

    # Use high-precision timer for accurate measurements
    start_time = time.perf_counter()
    try:
        result = solver.solve(timeout=timeout)
    except Exception as e:
        result = f"ERROR: {e}"
    end_time = time.perf_counter()

    # Measure elapsed time with microsecond precision
    elapsed = round(end_time - start_time, 6)

    stats = solver.get_statistics()
    return {
        "instance": os.path.basename(file_path),
        "solver": solver_name.upper(),
        "result": result,
        "time_sec": elapsed,
        "decisions": stats.get("decisions", "-"),
        "clauses_generated": stats.get("clauses_generated", "-")
    }

def main():
    parser = argparse.ArgumentParser(description="Run SAT Solver Benchmark")
    parser.add_argument("--solver", type=str, required=True, choices=["resolution", "dp", "dpll", "cdcl"])
    parser.add_argument("--input", type=str, required=True, help="Path to CNF file or folder of .cnf files")
    parser.add_argument("--timeout", type=int, default=None)
    parser.add_argument("--output", type=str, default="results.csv")

    args = parser.parse_args()

    input_path = args.input
    if os.path.isdir(input_path):
        files = [os.path.join(input_path, f) for f in os.listdir(input_path) if f.endswith(".cnf")]
    else:
        files = [input_path]

    results = []
    for file in files:
        result = run_solver(args.solver, file, args.timeout)
        results.append(result)

    print("\n--- Summary ---")
    for r in results:
        print(r)

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

    print(f"\nResults saved to {args.output}")

if __name__ == "__main__":
    main()
