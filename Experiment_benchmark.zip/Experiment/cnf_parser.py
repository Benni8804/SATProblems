def parse_dimacs(file_path):
    clauses = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(('c', 'p', '%', '0')):
                continue
            tokens = line.split()
            if tokens[-1] == '0':
                tokens = tokens[:-1]  # remove trailing 0
            literals = list(map(int, tokens))
            if literals:
                clauses.append(literals)
    return clauses
