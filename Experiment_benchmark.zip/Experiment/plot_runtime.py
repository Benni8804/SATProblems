import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('results.csv')
df = df[df['result'] != 'TIMEOUT']

# Korrigierter Pivot mit 'time_sec'
pivot_df = df.pivot(index='instance', columns='solver', values='time_sec')

pivot_df.plot(kind='bar', figsize=(10, 6))
plt.ylabel('Execution Time (s)')
plt.title('SAT Solver Runtime Comparison')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig('runtime_plot.pdf')
plt.show()
