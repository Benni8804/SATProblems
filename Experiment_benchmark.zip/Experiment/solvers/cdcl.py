from pysat.formula import CNF
from pysat.solvers import Solver

class CDCLSolver:
    def __init__(self, clauses):
        self.clauses = clauses
        self.decisions = 0
        self.result = None
        self.model = None

    def solve(self, timeout=None):
        cnf = CNF(from_clauses=self.clauses)

        # Try using glucose4 or another backend that supports stats
        with Solver(name='glucose4', bootstrap_with=cnf) as solver:
            if solver.solve():
                self.result = "SAT"
                self.model = solver.get_model()
            else:
                self.result = "UNSAT"

            stats = solver.accum_stats()
            self.decisions = stats.get("decisions", 0)

        return self.result

    def get_statistics(self):
        return {
            "decisions": self.decisions,
            "clauses_generated": "-"
        }

    def get_model(self):
        return self.model
