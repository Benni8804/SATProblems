import time
from collections import defaultdict
from copy import deepcopy

class DPSolver:
    def __init__(self, clauses):
        # Deep copy clauses to avoid modifying the original
        self.clauses = [set(clause) for clause in deepcopy(clauses)]
        self.variables = set(abs(lit) for clause in self.clauses for lit in clause)
        self.generated_count = 0
        self.result = None

    def pick_variable(self):
        # Heuristic: pick variable with fewest total appearances
        counts = defaultdict(int)
        for clause in self.clauses:
            for lit in clause:
                counts[abs(lit)] += 1
        return min(self.variables, key=lambda v: counts[v])

    def is_tautology(self, clause):
        return any(-lit in clause for lit in clause)

    def solve(self, timeout=None, max_clauses=None):
        start_time = time.time()

        num_vars = len(self.variables)
        if max_clauses is None:
            max_clauses = 500000 if num_vars <= 50 else 100000

        while self.variables:
            # Check for timeout condition
            if timeout and (time.time() - start_time) > timeout:
                self.result = "TIMEOUT"
                return self.result

            # Pure literal elimination
            literal_counts = defaultdict(int)
            for clause in self.clauses:
                for lit in clause:
                    literal_counts[lit] += 1

            pure_literals = {var for var in self.variables if var in literal_counts and -var not in literal_counts}
            pure_literals |= {var for var in self.variables if -var in literal_counts and var not in literal_counts}

            # Eliminate pure literals
            for var in list(pure_literals):
                self.clauses = [c for c in self.clauses if var not in c and -var not in c]
                self.variables.discard(var)

            # If no variables left, the formula is satisfiable
            if not self.variables:
                break

            # Pick the next variable to work with
            var = self.pick_variable()

            pos = [c for c in self.clauses if var in c]
            neg = [c for c in self.clauses if -var in c]
            rest = [c for c in self.clauses if var not in c and -var not in c]

            # New clauses generated after resolving
            new_clauses = []
            seen = set()
            new_clause_budget = max_clauses - len(rest)

            # Resolving positive and negative clauses
            for c1 in pos:
                for c2 in neg:
                    if new_clause_budget <= 0:
                        self.result = "TIMEOUT"
                        return self.result

                    resolvent = (c1 | c2) - {var, -var}

                    # Check for empty clause (conflict)
                    if not resolvent:
                        self.result = "UNSAT"
                        return self.result

                    key = frozenset(resolvent)
                    # Skip tautologies and duplicate clauses
                    if not self.is_tautology(resolvent) and key not in seen:
                        seen.add(key)
                        new_clauses.append(resolvent)
                        new_clause_budget -= 1

            # Update the clauses with the new resolvents
            self.generated_count += len(new_clauses)
            self.clauses = rest + new_clauses
            self.variables.remove(var)

            # Early exit if too many clauses are generated
            if self.generated_count > max_clauses:
                self.result = "TIMEOUT"
                return self.result

        # If there are no variables left, the formula is satisfiable
        self.result = "SAT"
        return self.result

    def get_statistics(self):
        return {
            "decisions": "-",
            "clauses_generated": self.generated_count
        }
