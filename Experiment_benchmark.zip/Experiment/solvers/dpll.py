class DPLLSolver:
    def __init__(self, clauses):
        self.original_clauses = clauses
        self.result = None
        self.model = {}
        self.decisions = 0

    def solve(self, timeout=None):
        variables = set(abs(lit) for clause in self.original_clauses for lit in clause)
        result, model = self._dpll(self.original_clauses, {}, variables)
        self.result = "SAT" if result else "UNSAT"
        self.model = model if result else {}
        return self.result

    def get_model(self):
        if self.result != "SAT":
            return None
        return [var if val else -var for var, val in self.model.items()]

    def get_statistics(self):
        return {
            "decisions": self.decisions,
            "clauses_generated": "-"
        }

    def _dpll(self, clauses, model, variables):
        clauses, model = self._unit_propagate(clauses, model)
        if clauses is None:
            return False, {}
        clauses, model = self._pure_literal_assign(clauses, model)
        if clauses is None:
            return False, {}
        if not clauses:
            return True, model
        unassigned_vars = variables - set(model.keys())
        if not unassigned_vars:
            return False, {}
        var = next(iter(unassigned_vars))
        for value in [True, False]:
            self.decisions += 1
            new_model = model.copy()
            new_model[var] = value
            simplified_clauses = self._simplify(clauses, var if value else -var)
            if simplified_clauses is not None:
                sat, final_model = self._dpll(simplified_clauses, new_model, variables)
                if sat:
                    return True, final_model
        return False, {}

    def _unit_propagate(self, clauses, model):
        changed = True
        while changed:
            changed = False
            unit_clauses = [c for c in clauses if len(c) == 1]
            for unit in unit_clauses:
                lit = unit[0]
                var = abs(lit)
                val = lit > 0
                if var in model:
                    if model[var] != val:
                        return None, {}
                    continue
                model[var] = val
                clauses = self._simplify(clauses, lit)
                if clauses is None:
                    return None, {}
                changed = True
        return clauses, model

    def _pure_literal_assign(self, clauses, model):
        literals = [lit for clause in clauses for lit in clause]
        counts = {}
        for lit in literals:
            counts[lit] = counts.get(lit, 0) + 1
        assigned = set()
        for lit in counts:
            var = abs(lit)
            if var in model or var in assigned:
                continue
            if -lit not in counts:
                val = lit > 0
                model[var] = val
                clauses = self._simplify(clauses, lit)
                if clauses is None:
                    return None, {}
                assigned.add(var)
        return clauses, model

    def _simplify(self, clauses, lit):
        new_clauses = []
        for clause in clauses:
            if lit in clause:
                continue
            new_clause = [l for l in clause if l != -lit]
            if not new_clause:
                return None
            new_clauses.append(new_clause)
        return new_clauses
