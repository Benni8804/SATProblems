import time

class ResolutionSolver:
    def __init__(self, clauses):
        self.original_clauses = [set(c) for c in clauses]
        self.clauses = set(frozenset(c) for c in self.original_clauses)
        self.generated = set()
        self.empty_derived = False
        self.total_resolutions = 0

    def resolve(self, c1, c2):
        """Generate all valid resolvents from c1 and c2."""
        resolvents = set()
        for lit in c1:
            if -lit in c2:
                new_clause = (c1 | c2) - {lit, -lit}
                # Skip tautological clauses
                if any(-l in new_clause for l in new_clause):
                    continue
                resolvents.add(frozenset(new_clause))
        return resolvents if resolvents else None

    def solve(self, timeout=None):
        start_time = time.time()
        new = set()

        while True:
            clause_list = list(self.clauses)
            progress = False

            for i in range(len(clause_list)):
                for j in range(i + 1, len(clause_list)):
                    if timeout and (time.time() - start_time) > timeout:
                        return 'TIMEOUT'

                    resolvents = self.resolve(clause_list[i], clause_list[j])
                    if resolvents:
                        for resolvent in resolvents:
                            if not resolvent:
                                self.empty_derived = True
                                return 'UNSAT'
                            if resolvent not in self.clauses and resolvent not in self.generated:
                                new.add(resolvent)
                                progress = True
                                self.total_resolutions += 1

            if not progress:
                break

            self.clauses.update(new)
            self.generated.update(new)
            new.clear()

        return 'SAT' if not self.empty_derived else 'UNSAT'

    def get_statistics(self):
        return {
            'clauses_generated': len(self.generated),
            'decisions': self.total_resolutions
        }
